#include <QGuiApplication>
#include <QQmlApplicationEngine>
#include <QQmlContext>
#include "QDebug"
#include "monappli.h"
#include "apislimtest.h"
#include "ui_apislimtest.h"
#include <QNetworkAccessManager>
#include <QNetworkReply>

int main(int argc, char *argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QCoreApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
#endif

    QGuiApplication app(argc, argv);

    MonAppli p;// Créer un objet de type MonAppli qui se nomme p
    MonAppli g;// Créer un objet de type MonAppli qui se nomme g
    MonAppli n;// Créer un objet de type MonAppli qui se nomme n
    MonAppli f;

    QQmlApplicationEngine engine;

    engine.rootContext()->setContextProperty("monObjet", &p);
    engine.rootContext()->setContextProperty("monConnexion", &g);
    engine.rootContext()->setContextProperty("maReservation", &n);
    engine.rootContext()->setContextProperty("maSpectacle", &f);

    const QUrl url(QStringLiteral("qrc:/main.qml"));

    QObject::connect(&engine, &QQmlApplicationEngine::objectCreated,
                     &app, [url](QObject *obj, const QUrl &objUrl) {
        if (!obj && url == objUrl)
            QCoreApplication::exit(-1);
    }, Qt::QueuedConnection);
    engine.load(url);

    return app.exec();
}
