#ifndef MONAPPLI_H
#define MONAPPLI_H
#include <QObject>
#include <QNetworkReply>

class MonAppli : public QObject
{
    Q_OBJECT
//  Q_PROPERTY(type name READ name WRITE setName NOTIFY pageLettre)
    Q_PROPERTY(QString DateSpectacle READ getDate WRITE setDate NOTIFY envoyerDate)
public:
    explicit MonAppli(QObject *parent = nullptr);
    Q_INVOKABLE void changerPage(int numPage);// J'ai créer une méthode de type Q_INVOKABLE se nomme changerPage et aussi dans cette méthode j'ai créer un objet de type int qui se nomme numPage
    Q_INVOKABLE void afficherConnexion(QString nom, QString prenom,QString codeBillet);
    Q_INVOKABLE void afficherNumP(QString NumPlaque);
    Q_INVOKABLE void afficherSpectacle(QString Nom,QString Prenom,QString CB);
    Q_INVOKABLE void afficherDonneesSpectacle();
    QString getDate();
    void setDate(QString d);

signals: // c'est un évenement qui a produit
    void pageAfficher(int num);
    void pageConnexion(bool reponse); // J'ai créer une méthode de type void qui se nomme pageLettre
    void pageSpectacle(bool reponse1);
    void envoyerDonneesSpectacle(QString laDate, QString Debut, QString Fin, QString Nom_Spectacle);
    void envoyerDate();

public slots:// c'est une méthode qui est appelé lorsque l'évènement est produit
    void getReponse(QNetworkReply *reply);
    void getReponseSpectacle(QNetworkReply *reply1);


private:
    int pageEnCours;
    QNetworkAccessManager *nm = new QNetworkAccessManager(this);
    QNetworkAccessManager*nm1 = new QNetworkAccessManager(this);
    QNetworkAccessManager*nm2 = new QNetworkAccessManager(this);

    QString laDate;
    int Debut;
    int Fin;
    QString Nom_Spectacle;


  //  QString txt;
};

#endif // MONAPPLI_H
