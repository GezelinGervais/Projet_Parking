#ifndef APISLIMTEST_H
#define APISLIMTEST_H


class apislimtest
{
public:
    apislimtest();
};

#endif // APISLIMTEST_H
