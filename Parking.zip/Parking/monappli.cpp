#include "monappli.h"
#include "QNetworkAccessManager"
#include <QNetworkReply>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QtQml>

MonAppli::MonAppli(QObject *parent) : QObject(parent){
    pageEnCours = 0;
    QObject::connect(nm, SIGNAL(finished(QNetworkReply *)),this, SLOT(getReponse(QNetworkReply *)));
    QObject::connect(nm2, SIGNAL(finished(QNetworkReply *)),this, SLOT(getReponseSpectacle(QNetworkReply *)));
}
void MonAppli:: afficherConnexion(QString nom, QString prenom,QString codeBillet ){


   QUrl url("http://parcking.fr/req1?Nom="+nom+ '&' + "Prenom="+prenom+'&'+ "CodeBillet="+codeBillet);// on fait une conconcaténation
   nm->get(QNetworkRequest(url));// le pointeur nm permet demander à la base de donéee en utilisant la terme request et get
}

void MonAppli::getReponse(QNetworkReply *reply){

   bool boo = false;//on a créer une variable de type booléean et on dit au tout début qu'il est fausse
    if(reply->error() == QNetworkReply::NoError) {
       QString jsonQString = (QString)reply->readAll();//c'est les donnée envoyer par la BD
       jsonQString=jsonQString.remove('[');// J'enleve les crochet
       jsonQString=jsonQString.remove(']');
      // qDebug()<<jsonQString;
         // C'est pour Transformer MSQL en JSON
              QByteArray jsonQByteArray= jsonQString.toUtf8();
              QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonQByteArray);
              QJsonObject jsonObject = jsonDoc.object();
              QStringList listCle=jsonObject.keys();
        // C'est pour mettre un tableau et que ce tableau sera séparer grâce au type qu'on insére pour afficher
        for(int i=0;i<jsonObject.size();i++){
            QJsonValue value = jsonObject.value(listCle[i]);
            if(value.isDouble()){
              double valeur=value.toDouble();
              if (valeur!= 0){// si les id_spectacles est différete de 0
                   boo = true; // alors la variable sera vrai

              }
             qDebug()<< "Key= " <<listCle[i]<< ",Value= " <<valeur;

            }
        }
    }
    else{// C'est un message pour dire qu'il aura une erreur lorsqu'il n'affiche pas les tableaux
        qDebug() << "ERROR";
    }
  emit pageConnexion(boo);
}

void MonAppli::afficherNumP(QString numPlaque){
    QUrl url("http://parcking.fr/add/reservationparking?NumPlaque="+numPlaque);// on fait une conconcaténation
    nm1->get(QNetworkRequest(url));// le pointeur nm permet demander à la base de donéee en utilisant la terme request et get
}
void MonAppli::afficherSpectacle(QString Nom, QString Prenom, QString CB){
    QUrl url("http://parcking.fr/req2?Nom="+Nom+ '&' + "Prenom="+Prenom+'&'+ "CodeBillet="+CB);// on fait une conconcaténation
    nm2->get(QNetworkRequest(url));// le pointeur nm permet demander à la base de donéee en utilisant la terme request et get
}
void MonAppli::getReponseSpectacle(QNetworkReply *reply1){

   bool spectacle = false;//on a créer une variable de type booléean et on dit au tout début qu'il est fausse
    if(reply1->error() == QNetworkReply::NoError) {
       QString jsonQString = (QString)reply1->readAll();//c'est les donnée envoyer par la BD
       jsonQString=jsonQString.remove('[');// J'enleve les crochet
       jsonQString=jsonQString.remove(']');
       //qDebug()<<jsonQString;

         // C'est pour Transformer MSQL en JSON
              QByteArray jsonQByteArray= jsonQString.toUtf8();
              QJsonDocument jsonDoc = QJsonDocument::fromJson(jsonQByteArray);
              QJsonObject jsonObject = jsonDoc.object();
              QStringList listCle1=jsonObject.keys();
        // C'est pour mettre un tableau et que ce tableau sera séparer grâce au type qu'on insére pour afficher
        for(int i=0;i<jsonObject.size();i++){
            QJsonValue value = jsonObject.value(listCle1[i]);
            if(value.isString()){
                  QString valeur=value.toString();
                  //qDebug()<<valeur;
                  spectacle = true; // alors la variable sera vrai
                 qDebug()<< "Key= " <<listCle1[i]<< ",Value= " <<valeur;
                 if(listCle1[i] == "Date") {
                     laDate = valeur;
                 } else if(listCle1[i] == "Nom_Spectacle") {
                     Nom_Spectacle = valeur;
                 }
            }
            if(value.isDouble()){
                spectacle = true;
                double D = value.toDouble();
                qDebug() << "Key = " << listCle1[i] << ", Value = " << D;
                if(listCle1[i] == "Debut") {
                    Debut = D;
                } else if(listCle1[i] == "Fin") {
                    Fin = D;
                }
            }
        }
//        qDebug() << "Date = " << laDate;
        qDebug() << "Debut = " << Debut;
        qDebug() << "Fin = " << Fin;
        qDebug() << "Nom du spectacle = " << Nom_Spectacle;
    }


    else{// C'est un message pour dire qu'il aura une erreur lorsqu'il n'affiche pas les tableaux
        qDebug() << "ERROR";
    }
  emit pageSpectacle(spectacle);
}

void MonAppli::afficherDonneesSpectacle() {
    qDebug() << "afficherDonneesSpectacle";
    emit envoyerDonneesSpectacle(laDate, QString::number(Debut), QString::number(Fin), Nom_Spectacle);


}

void MonAppli::changerPage(int num){
    emit pageAfficher(num);
}

QString MonAppli::getDate(){
    return laDate;
}

void MonAppli::setDate(QString D){
    laDate = D;
    emit envoyerDate();
}


